package senerio.one;

public abstract class Beef_Burger implements Item {
	@Override
	public abstract float price();

}
