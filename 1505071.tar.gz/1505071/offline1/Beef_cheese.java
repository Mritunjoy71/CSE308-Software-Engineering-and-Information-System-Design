package senerio.one;

public class Beef_cheese extends Beef_Burger{
	@Override
	   public float price() {
	      return 25.0f;
	   }

	   @Override
	   public String name() {
	      return "Beef cheese Burger";
	   }

}
