package senerio.one;

public class Beef_patty extends Beef_Burger {
	 @Override
	   public float price() {
	      return 25.0f;
	   }

	   @Override
	   public String name() {
	      return "Beef patty Burger";
	   }
}
