package scenerio.two;

public interface Coffee {	
	public String name();
	public String coffee_ingridients();
	public float price();
}
