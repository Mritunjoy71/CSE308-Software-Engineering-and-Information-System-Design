package senerio.one;

public interface Item {
	public String name();
	public float price();	

}

