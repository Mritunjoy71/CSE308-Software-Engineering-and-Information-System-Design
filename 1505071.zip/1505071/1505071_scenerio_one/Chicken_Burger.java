package senerio.one;

public abstract class Chicken_Burger implements Item {
	@Override
	public abstract String name();
	@Override
	public abstract float price();

}
