package senerio.one;

public class Chicken_cheese extends Chicken_Burger{
	@Override
	   public float price() {
	      return 25.0f;
	   }

	   @Override
	   public String name() {
	      return "Chicken cheese Burger";
	   }

}
